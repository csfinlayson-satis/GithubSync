# Durable function to be called by an orchestrator. Will update github repo versions of ARM templated rules
# This function requires repo_name and github_pat to be set in App settings
# Pass a dict of format {"id": "xxxx", "template": "xxxxx"} where id is rule id and template is ARM template
# CF Satisnet 8/23

# Imports
import logging
from github import Github
from github import Auth
import os

# Globals
repo_name = os.environ['repo_name']
github_pat = os.environ['github_pat']

# Accepts repo name (uname/reponame), filename, authed github object
# Returns list of Github file as github.File.File
# Searches repo for the file with filename. For this purpose should only return one value in list
def get_file(reponame, filename, g):
    logging.info(f"Searching repo: {reponame} for filename: {filename}")
    files = []
    # Get repo
    repo=g.get_repo(reponame)
    # Get all repo contents
    contents = repo.get_contents("")
    # Recursively go through contents, looking for match with "filename"
    while contents:
        # Get first file
        file_content = contents.pop(0)
        # If directory
        if file_content.type == "dir":
            # Add files in directory back to contents for recursion
            contents.extend(repo.get_contents(file_content.path))
        else:
            # Not a dir - do comparison, if match then add to return
            if file_content.name == filename:
                logging.info(f"Found match for {filename}")
                files.append(file_content)
    return files

# Accepts dict with {"id": "xxxx", "template": "xxxxx"} where id is rule id and template is ARM template
# Returns "done" when finished
# Sets up PyGithub, finds file in repo - if file exists will update with new template from input dictionary
def main(rule: dict) -> str:
    # Check that we have id and template
    if ('id' in rule) and ('template' in rule) and ('caller_name' in rule) and ('display_name' in rule):
        # Filename of type ruleid.json
        file_name = rule['id']+".json" 
        try:
            # Github setup
            auth = Auth.Token(github_pat)
            g = Github(auth=auth)
            sentinel_repo = g.get_repo(repo_name)
        except:
            logging.warn("Failed to connect to github and get repo - maybe bad github token or malformed repo")
            return "failed"
        # Find file(s) to update
        try:
            files_to_edit = get_file(repo_name,file_name,g)
        except:
            logging.warn(f"Error finding {file_name} in {repo_name}")
            return "failed"
        # Loop through files
        if files_to_edit:
            for file in files_to_edit:
                try:
                    logging.info(f"Updating {file_name}")
                    # Call github update, passing same file name, sha from current file, and new template
                    sentinel_repo.update_file(file.path, f"{rule['display_name']} - {rule['caller_name']}", rule['template'], file.sha)
                except:
                    # Something went wrong with update - warn
                    logging.warn(f"Unable to update {file_name}")
                    return "failed"
            # Return something?
            return "success"
        else:
            logging.info(f"Creating {file_name}")
            sentinel_repo.create_file(file_name, f"{rule['display_name']} - {rule['caller_name']}", rule['template'])
    else:
        if not (('id' in rule) and ('template' in rule)):
            logging.warn("id and template missing in github action")
        elif not 'id' in rule:
            logging.warn("id missing in github action")
        else:
            logging.warn("template missing in github action")
        return "failed"