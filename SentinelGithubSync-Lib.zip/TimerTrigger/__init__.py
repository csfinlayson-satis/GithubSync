# Timer trigger - settings in function.json
# Function gets last run time, as well as current run time, and passes these to main orchestrator and starts it
# CF Satisnet 8/23

# Imports
import datetime
import logging
import json
import azure.functions as func
import azure.durable_functions as df

# Globals
orchestrator_name = "MainOrchestrator"

# This will strip out redundant digit in time so we can use with datetime
def format_timestamp(badtime: str):
    first = badtime[: 26]
    last = badtime[27 :]
    logging.info(first+last)
    return first+last


# Using mytimer as string so we can pull last run time
async def main(mytimer: str, starter: str) -> None:
    # Grab the time now which will be used as current execution time
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()

    # Get the info associated with this timer run, parse it into dict
    timer_info = json.loads(mytimer)
    
    # Check if the timer ran late - log if so
    if timer_info['IsPastDue']:
        logging.info('The timer is past due!')

    # See what time the last run occured at, set up info to pass to orchestrator
    last_run = format_timestamp(timer_info['ScheduleStatus']['Last'])
    last_run = datetime.datetime.fromisoformat(last_run).astimezone(datetime.timezone.utc).isoformat()
    time_dict = {"now": utc_timestamp, "last":last_run}

    # Log run time and last run time, as well as value to pass to orchestrator
    logging.info('Python timer trigger function ran at %s last run was at %s', utc_timestamp, last_run)
    logging.info(time_dict)

    # Set up client and start main orchestrator
    client = df.DurableOrchestrationClient(starter)
    id = await client.start_new(orchestrator_name, None, time_dict)

    


