# Orchestrates LA pull and Github sync actions
# CF Satisnet 8/23

# Imports
import logging
import azure.functions as func
import azure.durable_functions as df

# Orchestrator function to call activities
def orchestrator_function(context: df.DurableOrchestrationContext):
    # Get the templates from LA by calling LogAnalyticsQuery activity and passing times (input)
    templates = yield context.call_activity('LogAnalyticsQuery', context.get_input())
    # Set up tasks to hold async github activities
    tasks = []
    # Go through all the templates
    for template in templates:
        tasks.append(context.call_activity("GithubActions", template))  #Add template to Github activity - append to task list
    # Asynchronously execute all github tasks
    results = yield context.task_all(tasks)
    # Return something
    return "done"

# Set up the orchestrator from above
main = df.Orchestrator.create(orchestrator_function)