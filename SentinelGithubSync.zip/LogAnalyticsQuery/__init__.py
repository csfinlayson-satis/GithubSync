# Durable function to be called by an orchestrator. Will query Log Analytics for updates to Sentinel rules
# This function requires minutes_offset and workspace_id to be set in App settings
# Pass a dict of form {'last': Datetime, 'now': Datetime} where last is last run time and now is now
# Returns a list of dicts of type {'id': 'xxx', 'template': 'xxx'} which are the most recent edit of rule templates in Sentinel
# CF Satisnet 8/23

# Imports
import logging
from azure.identity import ManagedIdentityCredential, DefaultAzureCredential
import azure.monitor.query as monitor
from azure.core.exceptions import HttpResponseError
import datetime
import os
import re

# Globals
minutes_offset = int(os.environ["QueryOffestInMins"])   #This is how far back the LA will look
workspace_id = os.environ["LogAnalyticsWorkspace"]
rule_types = ["Scheduled","NRT"]

# Takes the KQL row output (as a monitor.LogsTableRow) and returns an ARM template to be pushed to github
# HARD CODED INDEXES MEAN THIS MAY NEED TO BE EDITED IF THE KQL QUERY IS EDITED
def kusto_tidy(rowdata: monitor.LogsTableRow):
    # Get data from row - 0 is the newly updated rule, 1 is the rule type (scheduled, NRT, etc.), 2 is the rule ID
    try:
        new_rule_content = rowdata._row[0]  #Rule content from LA
        rule_type = rowdata._row[1] #Rule type from LA
        rule_id = rowdata._row[2]   #Rule ID from LA
        caller_name = rowdata._row[3]   #Caller name from LA
        display_name = rowdata._row[4]  #Rule display name from LA
    except:
        logging.error("Problem getting rule info - malformed KQL query possible")
    # Set up the strings to construct ARM template
    template_start = """{"$schema": "https://schema.management.azure.com/schemas/2019-04-01/deploymentTemplate.json#","contentVersion": "1.0.0.0","parameters": {"workspace": {"type": "String"}},"resources": [{"""
    id_line = f""""id": "[concat(resourceId('Microsoft.OperationalInsights/workspaces/providers', parameters('workspace'), 'Microsoft.SecurityInsights'),'/alertRules/{rule_id}')]","""
    name_line = f""""name": "[concat(parameters('workspace'),'/Microsoft.SecurityInsights/{rule_id}')]","""
    type_line = """"type":"Microsoft.OperationalInsights/workspaces/providers/alertRules","""
    api_line = """"apiVersion": "2022-11-01-preview","""
    template_end = """]}"""
    # Regex to remove ID, name, lastmodified, type, and etag - all of which are not needed in ARM template
    new_rule_content = re.sub(r'{\"id\"\s*:\s*\"[./\w-]*\"\s*,\s*\"name\"\s*:\s*\"[./\w-]*\"\s*,','',new_rule_content)
    new_rule_content = re.sub(r',\s*\"lastModifiedUtc\"\s*:\s*\"[\w.:-]+\"','',new_rule_content)
    new_rule_content = re.sub(r'\"type\"\s*:\s*\"[\w/.]*\"\s*,','',new_rule_content)
    new_rule_content = re.sub(r'\"etag\"\s*:\s*\"[\w/.\\\"-]*\"\s*,','',new_rule_content)
    # Construct and return ARM template
    new_rule_template = template_start + id_line + name_line + type_line + api_line + new_rule_content + template_end
    return {"id": rule_id, "template": new_rule_template, "caller_name":caller_name, "display_name":display_name}

# Accepts dict of times as described in file header comment
# Returns list of all arm templated with corresponding rule ID from KQL query executed on LA workspace
def main(times: dict) -> list:
    templates = []
    logging.info("Entering Log Analytics Query Activity with %s", str(times))
    # Get MI creds
    credential = ManagedIdentityCredential()
    logging.info("Setting up LA client using MI creds")
    # LA client setup
    client = monitor.LogsQueryClient(credential=credential)
    # Query here - if changing return change kusto_tidy fxn
    querystring = """let ruleschanged = (SentinelAudit| where ExtendedProperties.CallerName contains "@" and Description == "Create or update analytics rule."| summarize TimeGenerated=max(TimeGenerated) by rid=tostring(ExtendedProperties.ResourceId));SentinelAudit| extend rid=tostring(ExtendedProperties.ResourceId)| join kind=inner ruleschanged on TimeGenerated, rid| project ExtendedProperties.UpdatedResourceState, SentinelResourceKind, rid, ExtendedProperties.CallerName, ExtendedProperties.ResourceDisplayName"""
    
    start_time = datetime.datetime.fromisoformat(times['last']) - datetime.timedelta(minutes=minutes_offset)
    end_time = datetime.datetime.fromisoformat(times['now']) - datetime.timedelta(minutes=minutes_offset)
    logging.info("Executing query from"+start_time.strftime("%m/%d/%Y, %H:%M:%S.%z")+"to"+end_time.strftime("%m/%d/%Y, %H:%M:%S.%f"))
    # FOR PROD USE
    results = client.query_workspace(workspace_id,query=querystring,timespan=(start_time,end_time))
    # FOR TESTING USE ONLY
    #results = client.query_workspace(workspace_id,query=querystring,timespan=datetime.timedelta(days=5))
    # Catch LA HTTP reponse error
    try:
        # If successful LA query then extract all rows
        if results.status == monitor.LogsQueryStatus.SUCCESS:
            data = results.tables
            for table in data:
                column = table.columns
                for row in table.rows:
                    if row._row[1] in rule_types:   # Check that rule is correct type
                        templates.append(kusto_tidy(row))   #Pass row to kusto_tidy fxn to generate the template, append to returns
        elif results.status == monitor.LogsQueryStatus.PARTIAL:
            logging.warn("LA Query only partial success - data may be missing")
        elif results.status == monitor.LogsQueryStatus.FAILURE:
            logging.error("LA Query executed but encountered failure")
    except HttpResponseError as err:
        logging.error("Fatal error with LA query: "+err.message)
    # Return all templates
    return templates
